package com.xml.validator.controller;

public class SampleController {

}
